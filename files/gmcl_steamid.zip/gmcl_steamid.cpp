//Get SteamIDs client-side.
//Use ply:SteamID() to get a player's ID.
//Ex: require("steamid") print(player.GetByID(1):SteamID())
//Enjoy.  ~ers35

#define WIN32_LEAN_AND_MEAN
#include <string>
#include <sstream>
#include <GMLuaModule.h>
#include <cdll_int.h>

IVEngineClient *engine = NULL;

GMOD_MODULE(Start, End);

LUA_FUNCTION(SteamID)
{
	ILuaInterface *g_Lua = Lua();

	ILuaObject *ply = g_Lua->GetObject(1);
	ILuaObject *EntIndex = g_Lua->GetMetaTable("Entity", GLua::TYPE_ENTITY)->GetMember("EntIndex");
	
	g_Lua->Push(EntIndex);
		g_Lua->Push(ply);

	g_Lua->Call(1, 1);

	ILuaObject *retn = g_Lua->GetReturn(0);
	int entid = retn->GetInt();

	player_info_t plyinfo;
	engine->GetPlayerInfo(entid, &plyinfo);

	unsigned int friendid = plyinfo.friendsID;
	unsigned int steamid = friendid / 2;

	std::stringstream formattedID;
	formattedID << "STEAM_0:";
	friendid % 2 == 1 ? formattedID << "1:" : formattedID << "0:";
	formattedID << steamid;

	g_Lua->Push(formattedID.str().c_str());

	return 1;
}

int Start(lua_State *L)
{
	ILuaInterface *g_Lua = Lua();

	g_Lua->GetMetaTable("Entity", GLua::TYPE_ENTITY)->SetMember("SteamID", SteamID);

	CreateInterfaceFn engineFactory = Sys_GetFactory("engine.dll");
	engine = (IVEngineClient *)engineFactory(VENGINE_CLIENT_INTERFACE_VERSION, NULL);

	return 0;
}

int End(lua_State *L)
{
	return 0;
}

